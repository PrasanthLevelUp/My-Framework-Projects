A Pen created at CodePen.io. You can find this one at http://codepen.io/anon/pen/OgjdKM.

 A contact form built with Bootstrap 3. Field validation with Bootstrap Validator.