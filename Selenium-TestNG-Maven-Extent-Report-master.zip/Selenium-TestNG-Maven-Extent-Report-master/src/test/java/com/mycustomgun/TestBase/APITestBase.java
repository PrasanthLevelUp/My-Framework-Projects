package com.mycustomgun.TestBase;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONObject;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class APITestBase {

	public static String dest;
	public static String time;
	public static ExtentReports report;
	public static ExtentTest test;
	public static FileReader propreader;
	public static Properties prop;
	public WebDriver driver;
	public static FileInputStream excelinputStream;
	public static FileOutputStream exceloutputStream;
	public static File excelfile;
	public static XSSFWorkbook Workbook = null;
	public static XSSFSheet sheet = null;
	public static HashMap<String, String> cellvalues;
	public static int RowNo;
	public static RequestSpecification httpRequest;
	public static Response response;

	
	@BeforeTest
	public void Reportsetup() {
		try {
			this.loadpropertyfile();
			report = new ExtentReports("./ExtentReport/APIReport.html", true);
			report.addSystemInfo("HostName", "MCG").addSystemInfo("Environment", "Dev")
					.addSystemInfo("User", "Automation").addSystemInfo("Project Name", "MCGGunBuiler.com");
			report.loadConfig(new File(System.getProperty("user.dir") + "\\extent-config.xml"));
			this.readfile();
		} catch (Exception ex) {
			System.out.println("Issue is" + ex.getMessage());
		}
	}

	@AfterMethod
	public void getReport(ITestResult result) {
		try {
			if (result.getStatus() == ITestResult.FAILURE) {
				test.log(LogStatus.FAIL, result.getThrowable());
				test.log(LogStatus.FAIL, "Test Case Fail is:- " + result.getName());
			} else if (result.getStatus() == ITestResult.SUCCESS) {
				test.log(LogStatus.PASS, "Test Case pass is:- " + result.getName());
			} else if (result.getStatus() == ITestResult.SKIP) {
				test.log(LogStatus.SKIP, "test Case skip is:- " + result.getName());
			} else if (result.getStatus() == ITestResult.STARTED) {
				test.log(LogStatus.INFO, "Test Case started");
			}
			report.endTest(test);
		} catch (Exception es) {
			System.out.println(" Report genration Excepion is:- " + es.getMessage());
		}
	}

	@AfterTest
	public void endTest() {
		report.flush();
		report.close();
	}


	@SuppressWarnings("unchecked")
	public String getAccessToken(String email, String password) {
		RestAssured.baseURI = prop.getProperty("apibase_url");
		httpRequest = RestAssured.given();
		
		JSONObject requestParams = new JSONObject();
		requestParams.put("email", email); // Cast
		requestParams.put("password", password);
		
		httpRequest.header("Content-Type", "application/json");
		
		httpRequest.body(requestParams.toJSONString());
		try {
		response = httpRequest.request(Method.POST, "/api/auth/login");
		
		JsonPath jsonPathEvaluator = response.jsonPath();
		String accessToken = jsonPathEvaluator.get("accessToken");
		
		if(response.getStatusCode()==200)
		{
			test.log(LogStatus.PASS, "AuthTokem is created");
			return accessToken;
		}else {
			test.log(LogStatus.FAIL, "AuthTokem is not created");
			return null;
			
		}
		}catch(Exception e) {
			return null;
		}
	}
	
	public String getData(String columnName) {
		if(cellvalues.containsKey(columnName)) {
			return cellvalues.get(columnName);
		}else {
			return null;
		}
	}
	
	public void setData(String columnName,String value) throws IOException {
		if(cellvalues.containsKey(columnName)) {
			System.out.println("Set Data Started");
			cellvalues.put(columnName, value);
			for(int i=1;i<sheet.getRow(0).getLastCellNum();i++) {
				if(sheet.getRow(0).getCell(i).getStringCellValue().equalsIgnoreCase(columnName)) {
					sheet.getRow(RowNo).createCell(i).setCellValue(value);
					writefile();
					break;
				}
			}
		}else {
			System.out.println("Set Data Finished");
		}
	}

	public void loadpropertyfile() throws IOException {
		System.out.println("Property File Load Started");
		propreader = new FileReader("./src/main/resources/config.properties");
		prop = new Properties();
		prop.load(propreader);
		System.out.println("Property File Load Finished");
	}
	
	public void writefile() throws IOException {
		System.out.println("Excel write File Load Started");
		FileOutputStream outFile =new FileOutputStream(excelfile);
		Workbook.write(outFile);
        outFile.close();
		System.out.println("Excel write File Load Finished");
	}

	public void readfile() throws IOException {
		System.out.println("Excel File Load Started");
		excelfile = new File("./src/main/resources/TestDataSheet.xlsx");
		excelinputStream = new FileInputStream(excelfile);
		Workbook = new XSSFWorkbook(excelinputStream);
		sheet = Workbook.getSheet(prop.getProperty("apisheetname"));
		System.out.println("Excel File Load Finished");
	}
	
	public HashMap<String, String> getDatas(String TCName){
		System.out.println(TCName);
		System.out.println("Data Column Started");
		cellvalues = new HashMap<String, String>();
		RowNo = 0;
		for(int i=1;i<=sheet.getLastRowNum();i++) {
			if(sheet.getRow(i).getCell(0).getStringCellValue().equalsIgnoreCase(TCName)) {
				System.out.println("Row Value Fixed");
				RowNo = i;
				System.out.println(RowNo);
				break;
			}
		}
		for(int i=1;i<sheet.getRow(0).getLastCellNum();i++) {
			try {
			cellvalues.put(sheet.getRow(0).getCell(i).getStringCellValue(), sheet.getRow(RowNo).getCell(i).getStringCellValue());
			System.out.println(sheet.getRow(0).getCell(i).getStringCellValue() +" "+sheet.getRow(RowNo).getCell(i).getStringCellValue());
			}catch(Exception e) {
				cellvalues.put(sheet.getRow(0).getCell(i).getStringCellValue(),null);
			}
		}
		
		System.out.println("Data Column Finished");
		return cellvalues;
	}
	
}
