package com.mycustomgun.TestRunner.web;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.mycustomgun.TestBase.TestBase;
import com.mycustomgun.pages.HomePage;
import com.mycustomgun.pages.LowerPage;
import com.mycustomgun.pages.PlatformPage;
import com.relevantcodes.extentreports.LogStatus;

public class TC6_Verify_Lower_Selections extends TestBase{
	HomePage homepage;
	WebDriver driver;
	PlatformPage platform;
	LowerPage lowerform;

	@BeforeClass(groups = {"Regression"})
	public void launchApp() {
		driver = startBrowser(prop.getProperty("broswer"), prop.getProperty("base_url"));
		homepage = PageFactory.initElements(driver, HomePage.class);
		platform = PageFactory.initElements(driver, PlatformPage.class);
		getDatas(this.getClass().getSimpleName());
	}

	@Test(priority = 1, description = "This test case will validate GunBuilder Header",groups = {"Regression"})
	public void guestUser_FillLowerDetails_GunBuilder() throws InterruptedException {
		try {
			test = report.startTest(getData("Description"));
			test.log(LogStatus.INFO, "Test Started" + test.getStartedTime());
			homepage.clickGunbuilder();
			platform.clickPopup();
			platform.plaformpageselection();
			lowerform = PageFactory.initElements(driver, LowerPage.class);
			lowerform.lowerPageSelection();
			
		} catch (Exception ex) {
			System.out.println("Msg" + ex.getMessage());
		}
	}

	@AfterClass(groups = {"Regression"})
	public void endApp() {
		driver.close();
	}
}
