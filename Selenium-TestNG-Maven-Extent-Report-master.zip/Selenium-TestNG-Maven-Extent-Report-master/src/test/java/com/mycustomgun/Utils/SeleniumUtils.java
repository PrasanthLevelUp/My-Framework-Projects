package com.mycustomgun.Utils;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.mycustomgun.TestBase.TestBase;
import com.relevantcodes.extentreports.LogStatus;

public class SeleniumUtils extends TestBase {

	public void javascriptClick(WebElement ele, WebDriver driver, String desc) {
		try {
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);
			test.log(LogStatus.PASS, desc + test.addScreenCapture(takeScreenshot(driver)));
		} catch (Exception ex) {
			test.log(LogStatus.FAIL, ex.getMessage() + test.addScreenCapture(takeScreenshot(driver)));
		}
	}

	public String javascriptgetTextbyval(WebElement ele, WebDriver driver) {
		String returnText = null;
		try {
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			returnText = (String) executor.executeScript("return arguments[0].value", ele);
			test.log(LogStatus.PASS, "Returned value is "+returnText + test.addScreenCapture(takeScreenshot(driver)));
			return returnText;
		} catch (Exception ex) {
			test.log(LogStatus.FAIL, ex.getMessage() + test.addScreenCapture(takeScreenshot(driver)));
			return returnText;
		}
	}
	
	public String javascriptgetTextbyInnerHtml(WebElement ele, WebDriver driver) {
		String returnText = null;
		try {
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			returnText = (String) executor.executeScript("return arguments[0].innerHTML", ele);
			test.log(LogStatus.PASS, "Returned value is "+returnText + test.addScreenCapture(takeScreenshot(driver)));
			return returnText;
		} catch (Exception ex) {
			test.log(LogStatus.FAIL, ex.getMessage() + test.addScreenCapture(takeScreenshot(driver)));
			return returnText;
		}
	}
	
	public void seleSendKeys(WebElement ele, String val, String desc) {
		try {
			ele.sendKeys(val);
			test.log(LogStatus.PASS, desc + test.addScreenCapture(takeScreenshot(driver)));
		} catch (Exception ex) {
			test.log(LogStatus.FAIL, ex.getMessage() + test.addScreenCapture(takeScreenshot(driver)));

		}
	}
	
	public void asserstEqualsvalues(String Expected, String Actual) {
		try {
		Assert.assertEquals(Actual,Expected);
		test.log(LogStatus.PASS, "Assertion Expeced values is " +Expected +" Actual Values is "+Actual + test.addScreenCapture(takeScreenshot(driver)));
		}catch(Exception ex) {
			test.log(LogStatus.FAIL, "Assertion Expeced values is " +Expected +" Actual Values is "+Actual + test.addScreenCapture(takeScreenshot(driver)));
		}
	}
}
