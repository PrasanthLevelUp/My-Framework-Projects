package com.mycustomgun.Utils;

public class Test {

	public static void main(String[] args) {
		String str = "(+$0.00)";
		String sub1 = str.replace("(+$", "").replace(")", "");
		System.out.println(sub1);
		String sub2 = sub1.substring(0, sub1.length()-3);
		System.out.println(sub2);
	}

}
