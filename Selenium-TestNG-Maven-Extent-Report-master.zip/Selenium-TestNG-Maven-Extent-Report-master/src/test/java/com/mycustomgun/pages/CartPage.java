package com.mycustomgun.pages;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import com.mycustomgun.TestBase.TestBase;
import com.mycustomgun.Utils.SeleniumUtils;

public class CartPage extends TestBase{
	WebDriver driver;

	SeleniumUtils seleutils = new SeleniumUtils();

	public CartPage(WebDriver ldriver) {
		this.driver = ldriver;
	}

	@FindBy(css = "div.cart-container-parent div.cart-item-container div.cart-item-content") //if single item
	public WebElement guncontent;
	@FindBy(css = "div.cart-container-parent div.cart-item-container div.cart-item-price") //if single item
	public WebElement gunprice;
	@FindBy(css = "div.cart-container-parent div.cart-footer div.cart-total-price strong") //if single item
	public WebElement totalprice;
	@FindBy(css = "div.proceed-checkout button")
	public WebElement checkoutbtn;
	
	
	public void clickPopup() throws InterruptedException {
		//seleutils.javascriptClick(popupOKbtn, driver, "Click to Popup");
		Thread.sleep(2000);
		Assert.assertEquals(driver.getCurrentUrl(), "https://dev.mycustomgun.com/gbuilder1");
	}

}
