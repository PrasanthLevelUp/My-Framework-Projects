package com.mycustomgun.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.testng.Assert;

import com.mycustomgun.TestBase.TestBase;
import com.mycustomgun.Utils.SeleniumUtils;

public class CheckoutPage extends TestBase{
	WebDriver driver;

	SeleniumUtils seleutils = new SeleniumUtils();

	public CheckoutPage(WebDriver ldriver) {
		this.driver = ldriver;
	}

	@FindBys(@FindBy(css = "button span.v-btn__content")) //6th value
	public WebElement withoutloginbtn;
	@FindBys(@FindBy(css = "form.v-form input"))
	public List<WebElement> gundetails; 
	@FindBy(css = "div.gun-name button")
	public WebElement checkoutasguest;
	@FindBy(css = "div.step-btns button:nth-child(1)")
	public WebElement backbtn;
	
	
	public void clickPopup() throws InterruptedException {
		//seleutils.javascriptClick(popupOKbtn, driver, "Click to Popup");
		Thread.sleep(2000);
		Assert.assertEquals(driver.getCurrentUrl(), "https://dev.mycustomgun.com/gbuilder1");
	}

}
