package com.mycustomgun.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.testng.Assert;

import com.mycustomgun.TestBase.TestBase;
import com.mycustomgun.Utils.SeleniumUtils;

public class EngravingPage extends TestBase{
	WebDriver driver;

	SeleniumUtils seleutils = new SeleniumUtils();

	public EngravingPage(WebDriver ldriver) {
		this.driver = ldriver;
	}

	@FindBys(@FindBy(css = "div.v-stepper__header div:nth-child(2)"))
	public List<WebElement> headers;
	@FindBys(@FindBy(css = "div.st-dropdown-area div.st-selected-value")) //5th value
	public List<WebElement> selectedcolur; 
	@FindBys(@FindBy(css = "div.st-dropdown-area div.st-dropdown-content div.alignment p"))
	public List<WebElement> selectcolourbtn; 
	@FindBy(css = "div.step-btns button:nth-child(1)")
	public WebElement backbtn;
	@FindBy(css = "button#nextBtn")
	public WebElement nextbtn;
	@FindBy(css = "div.st-builder-gun-price")
	public WebElement gunprice;
	@FindBy(css = "table.item td")
	public WebElement selecteditemname;
	@FindBy(css = "table.price td")
	public WebElement selecteditemprice;
	@FindBy(css = "div.specifications div.description span:nth-child(2)")
	public WebElement selecteditemdescription;
	
	public void clickPopup() throws InterruptedException {
		//seleutils.javascriptClick(popupOKbtn, driver, "Click to Popup");
		Thread.sleep(2000);
		Assert.assertEquals(driver.getCurrentUrl(), "https://dev.mycustomgun.com/gbuilder1");
	}

}
