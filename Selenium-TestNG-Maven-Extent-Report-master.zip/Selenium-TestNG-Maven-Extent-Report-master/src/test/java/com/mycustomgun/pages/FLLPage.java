package com.mycustomgun.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.testng.Assert;

import com.mycustomgun.TestBase.TestBase;
import com.mycustomgun.Utils.SeleniumUtils;

public class FLLPage extends TestBase{
	WebDriver driver;

	SeleniumUtils seleutils = new SeleniumUtils();

	public FLLPage(WebDriver ldriver) {
		this.driver = ldriver;
	}

	@FindBy(css = "div.z-code input")
	public WebElement zipcode;
	@FindBy(css = "div.s-radius div.selectBox")
	public WebElement radius;
	@FindBys(@FindBy(css = "div.s-radius div.selectBoxOption")) //1-8
	public List<WebElement> radiusOption;
	@FindBy(css = "div.find-dealer")
	public WebElement finddealerbtn;
	@FindBys(@FindBy(css = "div.choose-d div.c-dealer")) //1-8
	public List<WebElement> dealerresults;
	@FindBy(css = "div.ffl-dealer div.dname")
	public WebElement delarnname;
		
	
	public void clickPopup() throws InterruptedException {
		//seleutils.javascriptClick(popupOKbtn, driver, "Click to Popup");
		Thread.sleep(2000);
		Assert.assertEquals(driver.getCurrentUrl(), "https://dev.mycustomgun.com/gbuilder1");
	}

}
