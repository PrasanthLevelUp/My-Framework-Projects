package com.mycustomgun.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;

import com.mycustomgun.TestBase.TestBase;
import com.mycustomgun.Utils.CommonUtils;
import com.mycustomgun.Utils.SeleniumUtils;

public class LowerPage extends TestBase{
	WebDriver driver;

	SeleniumUtils seleutils = new SeleniumUtils();
	CommonUtils comutils = new CommonUtils();

	public LowerPage(WebDriver ldriver) {
		this.driver = ldriver;
	}

	@FindBys(@FindBy(css = "div.v-stepper__header div:nth-child(2)"))
	public List<WebElement> headers;
	@FindBys(@FindBy(css = "div#step-2.tab-pane div.st-dropdown-area"))
	public List<WebElement> lowerattributes;
	@FindBy(css = "	div.step-btns button:nth-child(1)")
	public WebElement backbtn;
	@FindBy(css = "button#nextBtn")
	public WebElement nextbtn;
	@FindBy(css = "div.bot_disclamier div.st-builder-gun-price1")
	public WebElement gunprice;
	@FindBy(css = "table.item td")
	public WebElement selecteditemname;
	@FindBy(css = "table.price td")
	public WebElement selecteditemprice;
	@FindBy(css = "div.specifications div.description span:nth-child(2)")
	public WebElement selecteditemdescription;
	
	public void lowerPageSelection() {
		selectStripped();
		selectPartsKit();
		selectBufferTube();
		selectPistalGrip();
		selectTrigger();
		selectButtstock();
		selectMagazine();
		selectSafety();
		seleutils.javascriptClick(nextbtn, driver, "Click on Next Button");
	}
	
	public void selectStripped() {
		seleutils.javascriptClick(lowerattributes.get(0).findElement(By.cssSelector("div:nth-child(2)")), driver, "Click on Stripped Lower dropdown");
		List<WebElement> platformlist = lowerattributes.get(0).findElements(By.cssSelector("div:nth-child(3) button"));
		for(WebElement ele: platformlist) {
			if(seleutils.javascriptgetTextbyval(ele,driver).contains(getData("Stripped_Lower"))) {
			seleutils.javascriptClick(ele, driver, "Select the Stripped Lower");
			break;
			}
		}
	}
	public void selectPartsKit() {
		seleutils.javascriptClick(lowerattributes.get(1).findElement(By.cssSelector("div:nth-child(2)")), driver, "Click on Part Kit dropdown");
		List<WebElement> platformlist = lowerattributes.get(1).findElements(By.cssSelector("div:nth-child(3) button"));
		for(WebElement ele: platformlist) {
			if(seleutils.javascriptgetTextbyval(ele,driver).contains(getData("Part_Kit"))) {
			seleutils.javascriptClick(ele, driver, "Select the Part Kit");
			priceChecker(getData("Part_Kit_Price"),ele);
			break;
			}
		}
	}
	public void selectBufferTube() {
		seleutils.javascriptClick(lowerattributes.get(2).findElement(By.cssSelector("div:nth-child(2)")), driver, "Click on Buffer Tube dropdown");
		List<WebElement> listsofitems = lowerattributes.get(2).findElements(By.cssSelector("div:nth-child(3) div.st-radio-area label"));
		System.out.println(listsofitems);
		for(WebElement ele: listsofitems) {
			WebElement labelitem = ele.findElement(By.cssSelector("input"));
			if(seleutils.javascriptgetTextbyval(labelitem,driver).contains(getData("Buffer_Tube"))) {
			seleutils.javascriptClick(labelitem, driver, "Select the Buffer Tube");
			WebElement price = ele.findElement(By.cssSelector("span"));
			priceChecker(getData("Buffer_Tube_Price"),price);
			WebElement addbtn = ele.findElement(By.cssSelector("button"));
			seleutils.javascriptClick(addbtn, driver, "Add the Buffer Tube");
			break;
			}
		}
	}
	
	public void selectPistalGrip() {
		seleutils.javascriptClick(lowerattributes.get(3).findElement(By.cssSelector("div:nth-child(2)")), driver, "Click on Pistol Grip dropdown");
		List<WebElement> listsofitems = lowerattributes.get(3).findElements(By.cssSelector("div:nth-child(3) div.st-radio-area label"));
		System.out.println(listsofitems);
		for(WebElement ele: listsofitems) {
			WebElement labelitem = ele.findElement(By.cssSelector("input"));
			if(seleutils.javascriptgetTextbyval(labelitem,driver).contains(getData("Pistol_Grip"))) {
			seleutils.javascriptClick(labelitem, driver, "Select the Pistal Grip");
			WebElement price = ele.findElement(By.cssSelector("span"));
			priceChecker(getData("Pistol_Grip_Price"),price);
			WebElement addbtn = ele.findElement(By.cssSelector("button"));
			seleutils.javascriptClick(addbtn, driver, "Add the Pistal Grip");
			break;
			}
		}
	}
	
	public void selectTrigger() {
		seleutils.javascriptClick(lowerattributes.get(4).findElement(By.cssSelector("div:nth-child(2)")), driver, "Click on Trigger dropdown");
		List<WebElement> listsofitems = lowerattributes.get(4).findElements(By.cssSelector("div:nth-child(3) div.st-radio-area label"));
		System.out.println(listsofitems);
		for(WebElement ele: listsofitems) {
			WebElement labelitem = ele.findElement(By.cssSelector("input"));
			if(seleutils.javascriptgetTextbyval(labelitem,driver).contains(getData("Trigger"))) {
			seleutils.javascriptClick(labelitem, driver, "Select the Trigger");
			WebElement price = ele.findElement(By.cssSelector("span"));
			priceChecker(getData("Trigger_Price"),price);
			WebElement addbtn = ele.findElement(By.cssSelector("button"));
			seleutils.javascriptClick(addbtn, driver, "Add the Trigger");
			break;
			}
		}
	}

	public void selectButtstock() {
		seleutils.javascriptClick(lowerattributes.get(5).findElement(By.cssSelector("div:nth-child(2)")), driver, "Click on Buttstock dropdown");
		List<WebElement> listsofitems = lowerattributes.get(5).findElements(By.cssSelector("div:nth-child(3) div.st-radio-area label"));
		System.out.println(listsofitems);
		for(WebElement ele: listsofitems) {
			WebElement labelitem = ele.findElement(By.cssSelector("input"));
			if(seleutils.javascriptgetTextbyval(labelitem,driver).contains(getData("Buttstock"))) {
			seleutils.javascriptClick(labelitem, driver, "Select the Buttstock");
			WebElement price = ele.findElement(By.cssSelector("span"));
			priceChecker(getData("Buttstock_Price"),price);
			WebElement addbtn = ele.findElement(By.cssSelector("button"));
			seleutils.javascriptClick(addbtn, driver, "Add the Buttstock");
			break;
			}
		}
	}
	
	public void selectMagazine() {
		seleutils.javascriptClick(lowerattributes.get(6).findElement(By.cssSelector("div:nth-child(2)")), driver, "Click on Magazine dropdown");
		List<WebElement> platformlist = lowerattributes.get(6).findElements(By.cssSelector("div:nth-child(3) button"));
		for(WebElement ele: platformlist) {
			if(seleutils.javascriptgetTextbyval(ele,driver).contains(getData("Magazine"))) {
			seleutils.javascriptClick(ele, driver, "Select the Magazine");
			priceChecker(getData("Magazine_Price"),ele);
			break;
			}
		}
	}
	public void selectSafety() {
		seleutils.javascriptClick(lowerattributes.get(7).findElement(By.cssSelector("div:nth-child(2)")), driver, "Click on Safety dropdown");
		List<WebElement> platformlist = lowerattributes.get(7).findElements(By.cssSelector("div:nth-child(3) button"));
		for(WebElement ele: platformlist) {
			if(seleutils.javascriptgetTextbyval(ele,driver).contains(getData("Safety"))) {
			seleutils.javascriptClick(ele, driver, "Select the Safety");
			priceChecker(getData("Safety_Price"),ele);
			break;
			}
		}
	}
	
	public void priceChecker(String expectedval,WebElement ele) {
		String Actualprice = seleutils.javascriptgetTextbyInnerHtml(ele.findElement(By.cssSelector("p")),driver);
		String Actualprice1 =comutils.priceValidation(Actualprice.trim());
		seleutils.asserstEqualsvalues(expectedval,Actualprice1);
	}
	
}
