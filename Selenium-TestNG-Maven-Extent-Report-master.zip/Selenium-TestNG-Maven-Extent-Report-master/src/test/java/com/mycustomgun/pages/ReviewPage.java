package com.mycustomgun.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.testng.Assert;

import com.mycustomgun.TestBase.TestBase;
import com.mycustomgun.Utils.SeleniumUtils;

public class ReviewPage extends TestBase{
	WebDriver driver;

	SeleniumUtils seleutils = new SeleniumUtils();

	public ReviewPage(WebDriver ldriver) {
		this.driver = ldriver;
	}

	
	@FindBys(@FindBy(css = "form.v-form input")) //1,2,3,4
	public List<WebElement> cards;
	@FindBy(css = "div.center buttonr")
	public WebElement placeyourorder;
	@FindBys(@FindBy(css = "div.rightcontent tr td")) //1,2,3,4
	public List<WebElement> orederitems;
	@FindBy(css = "div.rightcontent p.order span")
	public WebElement totalprice;
	@FindBys(@FindBy(css = "div.subcontent div.sub1 p.subdetails span")) //1-7
	public List<WebElement> billingdetails;
	@FindBys(@FindBy(css = "div.subcontent div.sub2 p.subdetails span")) //1-5
	public List<WebElement> shippingdetails;
	@FindBys(@FindBy(css = "div.subcontent div.sub3 span")) //1-6
	public List<WebElement> flldetails;
	@FindBy(css = "div.subcontent div.sub1 i")
	public WebElement editbilling;
	@FindBy(css = "div.subcontent div.sub2 i")
	public WebElement editshipping;
	
		
	public void clickPopup() throws InterruptedException {
		//seleutils.javascriptClick(popupOKbtn, driver, "Click to Popup");
		Thread.sleep(2000);
		Assert.assertEquals(driver.getCurrentUrl(), "https://dev.mycustomgun.com/gbuilder1");
	}

}
