package com.mycustomgun.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.testng.Assert;

import com.mycustomgun.TestBase.TestBase;
import com.mycustomgun.Utils.SeleniumUtils;

public class ShippingPage extends TestBase{
	WebDriver driver;

	SeleniumUtils seleutils = new SeleniumUtils();

	public ShippingPage(WebDriver ldriver) {
		this.driver = ldriver;
	}

	@FindBy(css = "div.all div.d-flex.c-content button:nth-child(2)") //if single item
	public WebElement addtocardbtn;
	@FindBy(css = "div.all div.d-flex.c-content button:nth-child(1)") //if single item
	public WebElement deletebtn;
	@FindBy(css = "div.all div.d-flex.c-content")
	public WebElement createditem;
	@FindBys(@FindBy(css = "div.ship-content div.dflex div.flexgrow div.v-text-field__slot input")) //1,2
	public List<WebElement> shipdetails;
	@FindBys(@FindBy(css = "div.align input")) //1,2
	public List<WebElement> shipaddress;
	@FindBys(@FindBy(css = "div.dflex div.v-input--has-state div.v-input__slot")) //1,2,3
	public List<WebElement> cityzip;
	@FindBy(css = "div.v-select__selections")
	public WebElement state;
	@FindBys(@FindBy(css = "div.v-select-list div.v-list-item__title"))
	public List<WebElement> statelist;
	@FindBys(@FindBy(css = "div.contact-info div.flexgrow input"))
	public List<WebElement> contactinfo;
	@FindBy(css = "input#check")
	public WebElement checkbox;
	@FindBy(css = "div.contact-info div.btn button")
	public WebElement conituebtn;
	
	
	
	public void clickPopup() throws InterruptedException {
		//seleutils.javascriptClick(popupOKbtn, driver, "Click to Popup");
		Thread.sleep(2000);
		Assert.assertEquals(driver.getCurrentUrl(), "https://dev.mycustomgun.com/gbuilder1");
	}

}
